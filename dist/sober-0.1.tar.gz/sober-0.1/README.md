# soberconf

Attempts to help build sensible configuration for python projects.

* provide settings via toml file, keyword arguments or environment variables

* read secrets from toml file or vault or both

* can load environment variables from .env file

* supports environments

* allows to set path and mount point in vault 


## Limitations

* Only supports userpass and token authentication on Hashicorp Vault

* Only works with kv secret engine

* Only supports toml

(for now)


## Usage


### Settings

Soberconf(settings_file='path_to_file')
or environment variable SOBERCONF_SETTINGS_FILE="...""
or default settings.toml